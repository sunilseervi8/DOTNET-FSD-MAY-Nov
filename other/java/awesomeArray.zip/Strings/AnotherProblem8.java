package Strings;

public class AnotherProblem8 {
    
}
